﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
namespace advmorwal
{
    public partial class adminhome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null)
            {
                Label1.Text = Session["UserName"].ToString();
            }
            else
            {
             //   Response.Redirect("~/login.aspx");
            }
            
        }
        string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "varify")
            {
                int crow;
                crow = Convert.ToInt32(e.CommandArgument.ToString());
                string eid = GridView1.Rows[crow].Cells[0].Text;
                updatestatus(int.Parse(eid));
                
            }

        }
        public void updatestatus(int eid)
        {
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("update inquire set status='varified' where id = '"+eid+"'",con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
    }
}