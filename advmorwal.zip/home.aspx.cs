﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace advmorwal
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //save free consultation
            string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            DateTime now = DateTime.Now;
            string getlaw = DropDownList1.SelectedItem.ToString();
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("spinertconsult2", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name", TextBox1.Text);
                cmd.Parameters.AddWithValue("@mno", TextBox2.Text);
                cmd.Parameters.AddWithValue("@email", TextBox3.Text);
                cmd.Parameters.AddWithValue("@clow", getlaw.ToString());
                cmd.Parameters.AddWithValue("@mess", TextBox4.Text);
                cmd.Parameters.AddWithValue("@date", now.ToString());
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('consultation infomation Save Sucessfully we will inform soon.....!')", true);
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox3.Text = "";
                    TextBox4.Text = "";
                     
                }
                else
                { ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record not submit please fill again..!')", true); }
            }
         }
            /*  public void sendmailtoteam()
              {
                  SmtpClient smpt = new SmtpClient();
                  smpt.Host = "smtp.gmail.com";
                  smpt.Port = 587;
                  smpt.Credentials = new System.Net.NetworkCredential("wankush93@gmail.com", "9594974121");
                  smpt.EnableSsl = true;
                  MailMessage msg = new MailMessage();
                  msg.Subject = "Thank for Contact us";
                  msg.Body = "Dear Team \n the Person \t \n Name:" + TextBox1.Text + " ,   \n Mobile NO:" + TextBox2.Text + " \n Email:" + TextBox3.Text + "\n consult Reason:"+TextBox5.Text+" \n Message:" + TextBox4.Text + " \n\n\n    are contacting us  well be inform us \n\n\n  advmorwal.com";
                  string toaddress = "morwalpappu@gmail.com";
                  msg.To.Add(toaddress);
                  string fromaddress = "wankush93@gmail.com";
                  msg.From = new MailAddress(fromaddress);
                  try
                  {
                      smpt.Send(msg);
                  }
                  catch
                  {
                      throw;
                  }
              }*/
        }
}