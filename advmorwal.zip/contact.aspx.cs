﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace advmorwal
{
    public partial class contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string strcon = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            DateTime now = DateTime.Now;
            using (SqlConnection con = new SqlConnection(strcon))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("spinsert", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@name",TextBox2.Text);
                cmd.Parameters.AddWithValue("@mno",TextBox5.Text);
                cmd.Parameters.AddWithValue("@email",TextBox3.Text);
                cmd.Parameters.AddWithValue("@subject",TextBox4.Text);
                cmd.Parameters.AddWithValue("@mess", TextBox1.Text);
                cmd.Parameters.AddWithValue("@date",now.ToString());
                cmd.Parameters.AddWithValue("@status",  "unvarify");
                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Inquire Save Sucessfully we will inform soon.....!')", true);
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                    TextBox3.Text = "";
                    TextBox4.Text = "";
                    TextBox5.Text = "";
                }
                else
                { ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record not submit please fill again..!')", true); }
                con.Close();
            }
        }
       /* public void sendmailtoteam()
        {
            SmtpClient smpt = new SmtpClient();
            smpt.Host = "smtp.gmail.com";
            smpt.Port = 587;
            smpt.Credentials = new System.Net.NetworkCredential("wankush93@gmail.com", "9594974121");
            smpt.EnableSsl = true;
            MailMessage msg = new MailMessage();
            msg.Subject = "Thank for Contact us";
            msg.Body = "Dear Team \n the Person \t \n Name:" + TextBox2.Text + " ,   \n Mobile NO:" + TextBox5.Text + " \n Email:" + TextBox3.Text + " \n Message:" + TextBox1.Text + " \n\n\n    are contacting us  well be inform us \n\n\n  advmorwal.com";
            string toaddress = "morwalpappu@gmail.com";
            msg.To.Add(toaddress);
            string fromaddress = "wankush93@gmail.com";
            msg.From = new MailAddress(fromaddress);
            try
            {
                smpt.Send(msg);
            }
            catch
            {
                throw;
            }
        }   */
    }
}